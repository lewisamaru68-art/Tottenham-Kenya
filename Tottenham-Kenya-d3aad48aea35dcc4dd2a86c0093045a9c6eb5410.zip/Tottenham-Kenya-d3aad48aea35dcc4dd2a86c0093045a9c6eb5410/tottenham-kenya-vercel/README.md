# Tottenham Kenya - Vercel-ready
This is a Next.js starter site for Tottenham Kenya (fan site).

## To run locally
1. npm install
2. npm run dev
3. Open http://localhost:3000

## Deploy to Vercel
1. Push this repo to GitHub
2. Import project in Vercel (vercel.com) and deploy
